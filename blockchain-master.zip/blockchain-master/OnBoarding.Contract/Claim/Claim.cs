﻿namespace OnBoarding.Contract.Claim
{
    public class Claim
    {
        public bool Status { get; set; }

        public decimal ClaimAmmount { get; set; }

        public string Message { get; set; }
    }
}
