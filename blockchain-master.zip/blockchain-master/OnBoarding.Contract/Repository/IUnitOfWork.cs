﻿namespace OnBoarding.Contract.Repository
{
    public interface IUnitOfWork
    {
        void Commit();
    }
    
}
