﻿namespace OnBoarding.Contract.Policy
{
    public class Policy
    {
        public bool Status { get; set; }

        public string Message { get; set; }
    }
}
